from pathlib import Path
from PIL import Image
root=Path(__file__).resolve().parents[1]
for folder,prefix,n in [("assets/characters/goblin","hero",6),("assets/characters/zombies/basic","zombie",6)]:
  sizes=set()
  for i in range(n):
    f=root/folder/f"{prefix}_{i}.png"
    im=Image.open(f).convert("RGBA")
    sizes.add(im.size)
    bbox=im.getchannel("A").getbbox()
    assert bbox is not None, f"Empty frame: {f}"
    assert bbox[0]>=8 and bbox[2]<=im.width-8, f"Horizontal clipping risk: {f}, {bbox}"
    assert bbox[1]>=8 and bbox[3]<=im.height-5, f"Vertical clipping risk: {f}, {bbox}"
  assert len(sizes)==1, f"Mixed frame sizes in {folder}"
print("Sprite frames: dimensions and transparent margins validated")
