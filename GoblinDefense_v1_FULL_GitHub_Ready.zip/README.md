# Goblin Defense v1 — Android Godot project

A playable first prototype: goblin towers defend a crystal from incoming human waves.

## Contents
- `project.godot` — Godot 4.4.1 project and startup scene setting
- `scenes/main.tscn` — the actual main scene
- `scripts/game.gd` — gameplay logic: 4 types of towers, gold, upgrades, waves, opponents, projectiles, victory/defeat
- `export_presets.cfg` — Android export configuration
- `.github/workflows/android-apk.yml` — single GitHub Actions build workflow

## Upload from phone
1. Unzip this archive.
2. Upload ALL extracted files and folders to the root of a new, otherwise empty GitHub repository. Do not upload the ZIP as a file.
3. The root must contain `project.godot`, `export_presets.cfg`, `scenes`, `scripts` and `.github`.
4. Open GitHub Actions > Goblin Defense Android APK > Run workflow.
5. Download APK from Artifacts if build succeeds.

## Play
Choose a tower using the bottom toolbar, tap a circular pad to build, tap a built tower to select it and tap UPGRADE. Deselect by tapping empty ground; then tap NEXT WAVE. Complete 15 waves to win. Initial gold 180, crystal health 20.

The archive structure and required files have been checked. Android APK export/runtime has NOT been tested in this environment.
