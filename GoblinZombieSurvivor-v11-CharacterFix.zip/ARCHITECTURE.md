# Goblin Survivor: project structure

This is a **compatibility-first modular transition**, not yet a fully component-based ECS or fully decomposed scene graph. The existing working gameplay controller remains in `game.gd` for now.

- `main.tscn`: game entry scene.
- `game.gd`: existing run orchestration, combat update loops, HUD and rendering.
- `scripts/config/visual_catalog.gd`: **all visual paths and animation frame counts**. Change skin frame locations here.
- `scripts/config/enemy_catalog.gd`: **enemy archetype statistics** independent of graphics.
- `scripts/config/weapon_catalog.gd`: weapon parameters, effect ids and upgrade card descriptions.
- `scripts/services/progress_store.gd`: save/load isolated from gameplay.
- `assets/characters/`: character skin image sets; `assets/effects/`: attack and environment image sets; `assets/pickups/`, `assets/world/`.
- The top-level `assets/*.png` copies are retained temporarily for compatibility with older scripts; the new catalog uses organized locations.

## Swap a skin

Place the six PNG frames under a new folder (e.g. `assets/characters/zombies/armored/`) with names `zombie_0.png`..`zombie_5.png`, then update `ZOMBIE` in the visual catalog. For **different skins per enemy archetype**, the next refactor should introduce per-enemy visual definitions and local `AnimatedSprite2D` nodes. This release does not yet implement per-archetype skin selection.

## Planned next refactor

Move enemies to `scenes/actors/enemy.tscn` + `scripts/actors/enemy.gd`, projectiles to independent scenes, HUD to `CanvasLayer`, effects to reusable `AnimatedSprite2D` scenes, and progression to a run manager. Stage these changes separately to preserve the working Android build.

## Verification

Archive structure and path references can be validated offline. The updated GDScript has **not** been executed in Godot or Android here. Use GitHub Actions smoke test and an on-device check.
