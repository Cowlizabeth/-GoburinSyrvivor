@tool
extends EditorScript

func _run() -> void:
    var sdk := OS.get_environment("GODOT_CI_ANDROID_SDK")
    var java := OS.get_environment("JAVA_HOME")
    if sdk.is_empty() or java.is_empty():
        push_error("Android SDK / Java paths missing")
        return
    var settings := EditorInterface.get_editor_settings()
    settings.set_setting("export/android/android_sdk_path", sdk)
    settings.set_setting("export/android/java_sdk_path", java)
    settings.save()
    print("Configured Android SDK: ", sdk)
    print("Configured Java SDK: ", java)
