extends RefCounted
## Enemy archetypes are distinct from visual skins.
## New types can be introduced here, while rendering uses the visual catalog.
const TYPES := {
    "normal": {"health": 1.0, "speed": 1.0, "size": 1.0, "reward": 1, "skin": "basic"},
    "fast": {"health": 0.68, "speed": 1.7, "size": 0.82, "reward": 1, "skin": "basic"},
    "tank": {"health": 3.3, "speed": 0.72, "size": 1.25, "reward": 3, "skin": "basic"},
    "boss": {"health": 17.0, "speed": 0.55, "size": 1.72, "reward": 12, "skin": "basic"},
}

static func get_archetype(kind: String) -> Dictionary:
    return TYPES.get(kind, TYPES["normal"]).duplicate(true)
