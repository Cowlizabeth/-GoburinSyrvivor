# Goblin Zombie Survivor v8

Godot 4.4.1 pixel-art mobile portrait prototype. Android build via repository GitHub Actions workflow.

## New in v8
- Normal, fast, tank and boss zombies; boss appears every 90 seconds.
- Actual pixel-art XP crystals and coins, health pickups and magnet powerups.
- XP pickup, three upgrade cards, floating damage numbers, boss health bar.
- Coins saved to `user://goblin_progress.cfg` with three rotating persistent upgrades.
- More enemies and stronger enemies over time; auto fire, fan shot, volley and bombs retained.
- Six-frame run and walk animations, pixel FX from v6 and lower stage position from v7.

## Controls
- Game auto-runs and auto-shoots; tap one of the three level-up cards when it appears.
- After death tap the top part of the screen to restart, or the lower area to purchase a permanent upgrade if you have enough coins.
- Permanent upgrade purchase cycles through damage, maximum HP and faster shots.

## Important
The ZIP project has not been tested on a real Android device here. GitHub Actions compiles the APK; inspect the smoke-test stage and game logs before distribution. StykAnimate itself was not run; existing PNG frames are used by Godot.
