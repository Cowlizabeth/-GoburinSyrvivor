extends Node2D

@onready var animation: AnimatedSprite2D = $AnimatedSprite2D
var previous_move := "move"

func setup(frames: Array, frame_rate: float, display_size: Vector2, idle_frames: Array = [], attack_frames: Array = []) -> void:
    var resource := SpriteFrames.new()
    resource.add_animation("move")
    resource.set_animation_speed("move", frame_rate)
    resource.set_animation_loop("move", true)
    for texture in frames:
        resource.add_frame("move", texture)
    if not idle_frames.is_empty():
        resource.add_animation("idle")
        resource.set_animation_speed("idle", 5.0)
        resource.set_animation_loop("idle", true)
        for texture in idle_frames:
            resource.add_frame("idle", texture)
    if not attack_frames.is_empty():
        resource.add_animation("cast")
        resource.set_animation_speed("cast", 12.0)
        resource.set_animation_loop("cast", false)
        for texture in attack_frames:
            resource.add_frame("cast", texture)
    animation.sprite_frames = resource
    if not frames.is_empty():
        var size: Vector2 = frames[0].get_size()
        animation.scale = Vector2(display_size.x / size.x, display_size.y / size.y)
        animation.offset = Vector2(0.0, -size.y * 0.5)
    if not animation.animation_finished.is_connected(_on_animation_finished):
        animation.animation_finished.connect(_on_animation_finished)
    if resource.get_frame_count("move") > 0:
        animation.play("move")

func cast_spell() -> void:
    if animation.sprite_frames != null and animation.sprite_frames.has_animation("cast"):
        animation.play("cast")

func _on_animation_finished() -> void:
    if animation.animation == "cast":
        animation.play(previous_move)

func set_paused(value: bool) -> void:
    if value:
        animation.pause()
    elif not animation.is_playing() and animation.sprite_frames != null and animation.sprite_frames.has_animation(previous_move) and animation.sprite_frames.get_frame_count(previous_move) > 0:
        animation.play(previous_move)
