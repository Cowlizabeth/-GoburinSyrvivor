extends RefCounted
## Single place for visual asset paths and animation settings.
## Swap a skin by changing the base path here, without changing gameplay code.
const HERO := "res://assets/characters/goblin"
const ZOMBIE := "res://assets/characters/zombies/basic"
const BOLT := "res://assets/effects/magic_bolt"
const BOMB := "res://assets/effects/bomb"
const EXPLOSION := "res://assets/effects/explosion"
const ENVIRONMENT := "res://assets/effects/environment"
const WORLD := "res://assets/world"
const PICKUP := "res://assets/pickups"

const HERO_FRAMES := 9
const ZOMBIE_FRAMES := 6
const PROJECTILE_FRAMES := 3
const EXPLOSION_FRAMES := 6
const FIRE_FRAMES := 6
const WATER_FRAMES := 8
const ROCK_FRAMES := 5

static func animation_frames(folder: String, prefix: String, count: int) -> Array[Texture2D]:
    var frames: Array[Texture2D] = []
    for i in range(count):
        var resource_path: String = "%s/%s_%d.png" % [folder, prefix, i]
        var texture: Texture2D = load(resource_path)
        if texture != null:
            frames.append(texture)
        else:
            push_error("Missing animation frame: " + resource_path)
    return frames

static func pickup_texture(kind: String) -> Texture2D:
    return load("%s/pickup_%s.png" % [PICKUP, kind])

static func world_background() -> Texture2D:
    return load(WORLD + "/forest.png")
