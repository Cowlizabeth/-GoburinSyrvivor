extends Node2D

@onready var animation: AnimatedSprite2D = $AnimatedSprite2D

func setup(frames: Array[Texture2D], frame_rate: float, display_size: Vector2) -> void:
    var resource := SpriteFrames.new()
    resource.add_animation("move")
    resource.set_animation_speed("move", frame_rate)
    resource.set_animation_loop("move", true)
    for texture in frames:
        resource.add_frame("move", texture)
    animation.sprite_frames = resource
    if not frames.is_empty():
        var size: Vector2 = frames[0].get_size()
        animation.scale = Vector2(display_size.x / size.x, display_size.y / size.y)
        # Image pixel bottom is character's floor anchor; not its center.
        animation.offset = Vector2(0.0, -size.y * 0.5)
    animation.play("move")

func set_paused(value: bool) -> void:
    if value:
        animation.pause()
    elif not animation.is_playing():
        animation.play("move")
