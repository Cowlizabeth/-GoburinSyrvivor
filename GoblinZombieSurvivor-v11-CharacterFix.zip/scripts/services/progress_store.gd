extends RefCounted
## Versioned persistence boundary. No art or UI dependencies.
const FILE_PATH := "user://goblin_progress.cfg"

static func read_progress() -> Dictionary:
    var config := ConfigFile.new()
    if config.load(FILE_PATH) != OK:
        return {"coins": 0, "damage": 0, "hp": 0, "rate": 0}
    return {
        "coins": int(config.get_value("save", "coins", 0)),
        "damage": int(config.get_value("save", "damage", 0)),
        "hp": int(config.get_value("save", "hp", 0)),
        "rate": int(config.get_value("save", "rate", 0)),
    }

static func write_progress(data: Dictionary) -> void:
    var config := ConfigFile.new()
    for key in ["coins", "damage", "hp", "rate"]:
        config.set_value("save", key, int(data.get(key, 0)))
    var result := config.save(FILE_PATH)
    if result != OK:
        push_error("Could not save progress: " + str(result))
