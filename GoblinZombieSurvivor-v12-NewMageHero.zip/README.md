# Goblin Zombie Survivor v8

Godot 4.4.1 pixel-art mobile portrait prototype. Android build via repository GitHub Actions workflow.

## New in v8
- Normal, fast, tank and boss zombies; boss appears every 90 seconds.
- Actual pixel-art XP crystals and coins, health pickups and magnet powerups.
- XP pickup, three upgrade cards, floating damage numbers, boss health bar.
- Coins saved to `user://goblin_progress.cfg` with three rotating persistent upgrades.
- More enemies and stronger enemies over time; auto fire, fan shot, volley and bombs retained.
- Six-frame run and walk animations, pixel FX from v6 and lower stage position from v7.

## Controls
- Game auto-runs and auto-shoots; tap one of the three level-up cards when it appears.
- After death tap the top part of the screen to restart, or the lower area to purchase a permanent upgrade if you have enough coins.
- Permanent upgrade purchase cycles through damage, maximum HP and faster shots.

## Important
The ZIP project has not been tested on a real Android device here. GitHub Actions compiles the APK; inspect the smoke-test stage and game logs before distribution. StykAnimate itself was not run; existing PNG frames are used by Godot.


## v10: Fixed sprite cutoffs
Regenerated all character frames with a stable, complete upper-body silhouette, retaining animated leg poses. Unified texture sizes, transparency margins and sprite foot anchors; see tools/validate_frames.py.

## v11 Character Scene Refactor
- Actors render via scenes/characters/CharacterVisual.tscn with AnimatedSprite2D.
- Each sprite frame is a **whole PNG**, not upper-body/lower-body composites.
- Shared floor-anchor setup in scripts/characters/character_visual.gd.
- Current combat, loot, and progression logic retained in game.gd for compatibility.
- This is a transition to scene-based architecture; the rest of the code is not yet fully modular.
- APK and on-device rendering are not validated in this environment.


## v12 New Mage Hero
Replaced the active player hero with the newly drawn goblin mage run animation (9 frames, 256x256 each). The wide-spaced individual mage frames are also included under `assets/characters/goblin/` as `idle_*`, `run_*`, and `cast_*` for future state-based animation switching.
