# Character coordinate grid

Canonical cast PNG: 512x512, 32-pixel grid. Feet baseline: Y=420. All marker coordinates are measured in source-frame pixels. They are transformed into local Godot coordinates via frame scale.

| Cast frame | Muzzle pixel x | Muzzle pixel y |
|---:|---:|---:|
| 0 | 306 | 190 |
| 1 | 318 | 77 |
| 2 | 317 | 90 |
| 3 | 307 | 166 |
| 4 | 263 | 128 |
| 5 | 311 | 192 |
| 6 | 310 | 185 |
| 7 | 300 | 178 |

Cast release occurs when AnimatedSprite2D reaches frame 4. The marker position is updated before emitting cast_release. Cast animation duration follows `fire_interval`.
