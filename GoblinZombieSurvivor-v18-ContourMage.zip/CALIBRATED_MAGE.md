# Calibrated mage v17
- Six run frames and six cast frames, sourced from the latest user-approved calibration.
- Identical 416x416 transparent canvas and common foot baseline y=372.
- Release on cast frame 3 (zero-indexed; fourth visible pose).
- Marker2D muzzle points are frame-specific, and attack animation speed is tied to fire_interval.
- Pixel source x/y values are in game.gd.
- APK has not been built or tested in this environment.
