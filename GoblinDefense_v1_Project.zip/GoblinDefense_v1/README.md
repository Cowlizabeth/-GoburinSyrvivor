# Goblin Defense v0.1

Vertical Godot 4.4.1 tower-defense prototype. Goblins protect their crystal against waves of invading humans.

## Play
Select one of four towers at the bottom, then tap a circular build pad. Tap NEXT WAVE to start an attack. Tap an existing tower, then UPGRADE / NEXT to improve it (up to level 4). Protect the crystal through 15 waves. Tap below to restart after victory/defeat.

## Android using GitHub on a phone
1. Create a new public or private GitHub repository.
2. Unzip this archive locally and upload its **contents to the repository root**, including the hidden `.github/workflows/android.yml` file. Do not upload the ZIP as a single file.
3. In GitHub, open **Actions** → **Android APK** → **Run workflow**.
4. After the workflow finishes, open the run and download `GoblinDefense-Android-APK` under Artifacts. Extract the artifact ZIP and install `GoblinDefense-debug.apk`.

The workflow uses Godot 4.4.1 and creates a disposable debug signing key for each build. The APK is for local testing, not Google Play distribution. If Android treats versions as different signers, uninstall the previous testing APK before installing a newly built one (this removes local game data).

## Developer notes
Logic and visuals are independent from external PNG sprite sheets. Current visuals are procedurally drawn in `scripts/game.gd`. Next iterations should split enemy and tower properties into Resource files and use separate scene nodes/sprite assets.
