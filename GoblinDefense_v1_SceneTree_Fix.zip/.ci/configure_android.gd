extends SceneTree

func _initialize() -> void:
    var sdk: String = OS.get_environment("GODOT_CI_ANDROID_SDK")
    var java: String = OS.get_environment("JAVA_HOME")
    if sdk.is_empty() or java.is_empty():
        push_error("Android SDK or JAVA_HOME missing")
        quit(1)
        return
    var settings: EditorSettings = EditorInterface.get_editor_settings()
    settings.set_setting("export/android/android_sdk_path", sdk)
    settings.set_setting("export/android/java_sdk_path", java)
    settings.save()
    print("Android SDK configured: ", sdk)
    print("Java configured: ", java)
    quit(0)
