extends Node2D

const W := 540.0
const H := 1200.0
const FLOOR := 910.0
var hero_frames: Array[Texture2D] = []
var zombie_frames: Array[Texture2D] = []
var bolt_frames: Array[Texture2D] = []
var bomb_frames: Array[Texture2D] = []
var explosion_frames: Array[Texture2D] = []
var fire_frames: Array[Texture2D] = []
var water_frames: Array[Texture2D] = []
var rock_frames: Array[Texture2D] = []
var forest: Texture2D
var rng := RandomNumberGenerator.new()
var enemies: Array = []
var shots: Array = []
var effects: Array = []
var time_alive := 0.0
var spawn_timer := 0.0
var shot_timer := 0.0
var run_frame := 0.0
var level := 1
var xp := 0
var xp_target := 5
var kills := 0
var hp := 5
var max_hp := 5
var damage := 1.0
var fire_interval := 1.75
var triple := 0
var fan := 0
var bombs := 0
var volley: Array = []
var menu := false
var dead := false
var choices: Array = []
var scroll := 0.0
var font: Font

func _ready() -> void:
    rng.randomize()
    forest = load("res://assets/forest.png")
    for i in range(6): hero_frames.append(load("res://assets/hero_%d.png" % i))
    for i in range(6): zombie_frames.append(load("res://assets/zombie_%d.png" % i))
    for i in range(3):
        bolt_frames.append(load("res://assets/bolt_%d.png" % i))
        bomb_frames.append(load("res://assets/bomb_%d.png" % i))
    for i in range(6):
        explosion_frames.append(load("res://assets/explosion_%d.png" % i))
        fire_frames.append(load("res://assets/fire_%d.png" % i))
        if i < 5: rock_frames.append(load("res://assets/rock_%d.png" % i))
    for i in range(8):
        water_frames.append(load("res://assets/water_%d.png" % i))
    font = ThemeDB.fallback_font
    print("GOBLIN GAME READY: textures loaded")
    reset()

func reset() -> void:
    enemies.clear()
    shots.clear()
    effects.clear()
    volley.clear()
    time_alive = 0.0
    spawn_timer = 1.4
    shot_timer = 0.8
    run_frame = 0.0
    level = 1
    xp = 0
    xp_target = 5
    kills = 0
    hp = 5
    max_hp = 5
    damage = 1.0
    fire_interval = 1.7
    triple = 0
    fan = 0
    bombs = 0
    menu = false
    dead = false
    scroll = 0.0
    queue_redraw()

func _process(delta: float) -> void:
    if menu or dead:
        queue_redraw()
        return
    var dt: float = minf(delta, 0.05)
    time_alive += dt
    run_frame += dt * 11.0
    scroll += dt * (26.0 + time_alive * 0.18)
    spawn_timer -= dt
    if spawn_timer <= 0.0:
        spawn_zombie()
        var base_rate: float = maxf(0.32, 2.1 - time_alive * 0.012 - float(level - 1) * 0.11)
        spawn_timer = base_rate * rng.randf_range(0.75, 1.35)
    shot_timer -= dt
    if shot_timer <= 0.0:
        auto_fire()
        shot_timer = fire_interval
    for v in volley:
        v["delay"] -= dt
        if v["delay"] <= 0.0:
            fire_at(v["target"], v["spread"])
    volley = volley.filter(func(v): return v["delay"] > 0.0)
    update_projectiles(dt)
    update_zombies(dt)
    for e in effects:
        e["ttl"] -= dt
    effects = effects.filter(func(e): return e["ttl"] > 0.0)
    queue_redraw()

func spawn_zombie() -> void:
    var hp_value: float = 1.4 + float(level - 1) * 0.55 + time_alive * 0.018
    enemies.append({"p": Vector2(W + 56.0, FLOOR + rng.randf_range(-8.0, 8.0)), "hp": hp_value, "max": hp_value, "speed": 45.0 + minf(105.0, time_alive * 0.8) + float(level) * 2.5, "anim": rng.randf_range(0.0, 6.0), "hit": 0.0})

func auto_fire() -> void:
    if enemies.is_empty(): return
    var best: Dictionary = enemies[0]
    var dist: float = INF
    for e in enemies:
        var d: float = Vector2(146.0, FLOOR - 108.0).distance_squared_to(e["p"])
        if d < dist:
            dist = d
            best = e
    var aim: Vector2 = best["p"] + Vector2(0.0, -94.0)
    fire_at(aim, 0.0)
    if fan > 0:
        for n in range(1, fan + 1):
            fire_at(aim, float(n) * 0.17)
            fire_at(aim, float(n) * -0.17)
    for i in range(triple):
        volley.append({"delay": 0.16 * float(i + 1), "target": aim, "spread": 0.0})
    if bombs > 0:
        for n in range(bombs):
            shots.append({"p": Vector2(146.0, FLOOR - 116.0), "v": Vector2(195.0 + 25.0 * n, -370.0 - n * 35.0), "life": 3.0, "bomb": true, "dmg": damage * 2.5})

func fire_at(target: Vector2, spread: float) -> void:
    var origin := Vector2(146.0, FLOOR - 116.0)
    var dir: Vector2 = (target - origin).normalized().rotated(spread)
    shots.append({"p": origin, "v": dir * 470.0, "life": 1.7, "bomb": false, "dmg": damage})

func update_projectiles(dt: float) -> void:
    for s in shots:
        s["life"] -= dt
        s["p"] += s["v"] * dt
        if s["bomb"]:
            var vel: Vector2 = s["v"]
            vel.y += 650.0 * dt
            s["v"] = vel
            if s["p"].y >= FLOOR - 8.0:
                explosion(Vector2(clampf(s["p"].x, 84.0, W - 84.0), FLOOR - 8.0), s["dmg"])
                s["life"] = -1.0
        else:
            for z in enemies:
                if s["p"].distance_to(z["p"] + Vector2(0, -104)) < 48.0:
                    z["hp"] -= s["dmg"]
                    z["hit"] = 0.12
                    effects.append({"p": s["p"], "ttl": 0.2, "kind": "hit"})
                    s["life"] = -1.0
                    break
    shots = shots.filter(func(s): return s["life"] > 0.0 and s["p"].x < W + 90.0 and s["p"].y < H + 80.0)

func explosion(point: Vector2, power: float) -> void:
    point.x = clampf(point.x, 84.0, W - 84.0)
    effects.append({"p": point, "ttl": 0.42, "kind": "boom"})
    for z in enemies:
        if (z["p"] + Vector2(0, -70)).distance_to(point + Vector2(0, -35)) < 135.0:
            z["hp"] -= power
            z["hit"] = 0.18

func update_zombies(dt: float) -> void:
    var living: Array = []
    for z in enemies:
        var position: Vector2 = z["p"]
        position.x -= z["speed"] * dt
        z["p"] = position
        if position.x < -80.0:
            continue
        z["anim"] += dt * 8.0
        z["hit"] = maxf(0.0, z["hit"] - dt)
        if z["hp"] <= 0.0:
            kills += 1
            gain_xp(1)
            effects.append({"p": z["p"], "ttl": 0.4, "kind": "kill"})
        elif z["p"].x < 158.0:
            hp -= 1
            effects.append({"p": Vector2(120.0, FLOOR - 100.0), "ttl": 0.4, "kind": "hit"})
            if hp <= 0: dead = true
        else:
            living.append(z)
    enemies = living

func gain_xp(amount: int) -> void:
    xp += amount
    if xp >= xp_target and not menu:
        xp -= xp_target
        level += 1
        damage += 0.32
        xp_target = 5 + level * 3
        menu = true
        choices = ["TRIPLE SHOT", "FAN SHOT", "BOMB"]

func _input(event: InputEvent) -> void:
    if not (event is InputEventScreenTouch or event is InputEventMouseButton): return
    if not event.pressed: return
    if dead:
        reset()
        return
    if menu:
        var pos: Vector2 = event.position
        var scale_x: float = get_viewport_rect().size.x / W
        var scale_y: float = get_viewport_rect().size.y / H
        pos = Vector2(pos.x / scale_x, pos.y / scale_y)
        for i in range(3):
            if Rect2(56, 354 + i * 100, 428, 78).has_point(pos):
                if i == 0: triple += 2
                elif i == 1: fan += 1
                else: bombs += 1
                menu = false
                return

func tex(tex_in: Texture2D, at: Vector2, dims: Vector2, flip: bool = false) -> void:
    if tex_in == null: return
    draw_texture_rect(tex_in, Rect2(at + Vector2(-dims.x * 0.5, -dims.y), dims), false)

func label(text_value: String, pos: Vector2, size: int = 24, color: Color = Color.WHITE) -> void:
    draw_string(font, pos + Vector2(2, 2), text_value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(0.05, 0.08, 0.10, 0.85))
    draw_string(font, pos, text_value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func _draw() -> void:
    draw_rect(Rect2(0, 0, W, H), Color(0.15, 0.38, 0.55))
    # Extend the forest background vertically; lower strip remains the playable ground.
    draw_texture_rect(forest, Rect2(-fposmod(scroll * 0.24, 270.0), 110, 1100, FLOOR - 50.0), false)
    if water_frames.size() > 0:
        var wf: Texture2D = water_frames[int(time_alive * 8.0) % water_frames.size()]
        draw_texture_rect(wf, Rect2(396, 560, 84, 32), false)
    # Ground texture continues to bottom of portrait view, no gray letterbox.
    draw_rect(Rect2(0, FLOOR + 10, W, H - FLOOR), Color(0.11, 0.23, 0.16))
    for band in range(6):
        draw_rect(Rect2(0, FLOOR + 20 + band * 48, W, 18), Color(0.12, 0.22, 0.15, 0.12))
    draw_rect(Rect2(0, FLOOR, W, 10), Color(0.51, 0.75, 0.18))
    if fire_frames.size() > 0:
        draw_texture_rect(fire_frames[int(time_alive * 12.0) % fire_frames.size()], Rect2(458, FLOOR - 156, 34, 46), false)
    # horizon shimmer
    for i in range(7):
        var x: float = fposmod(float(i * 130) - scroll * 1.5, 780.0) - 90.0
        draw_rect(Rect2(x, FLOOR + 15, 34, 4), Color(0.35, 0.54, 0.17))
    if hero_frames.size() > 0:
        tex(hero_frames[int(run_frame) % hero_frames.size()], Vector2(120, FLOOR + 10), Vector2(164, 188))
    for z in enemies:
        tex(zombie_frames[int(z["anim"]) % zombie_frames.size()], z["p"] + Vector2(0, 8), Vector2(156, 192), false)
        if z["hit"] > 0: draw_circle(z["p"] + Vector2(0, -85), 12, Color(1, 0.2, 0.2, 0.75))
    for s in shots:
        if s["bomb"]:
            draw_set_transform(s["p"], time_alive * 6.0)
            tex(bomb_frames[int(time_alive * 13) % 3], Vector2.ZERO, Vector2(44, 44))
            draw_set_transform(Vector2.ZERO, 0.0)
        else:
            var bolt: Texture2D = bolt_frames[int(time_alive * 18.0) % bolt_frames.size()]
            draw_set_transform(s["p"], s["v"].angle(), Vector2.ONE)
            draw_texture_rect(bolt, Rect2(-26, -16, 52, 32), false)
            draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    for e in effects:
        if e["kind"] == "boom":
            var phase: int = clampi(int((0.42 - e["ttl"]) / 0.42 * 6.0), 0, 5)
            draw_texture_rect(explosion_frames[phase], Rect2(e["p"] - Vector2(80, 80), Vector2(160, 160)), false)
        elif e["kind"] == "kill":
            draw_circle(e["p"] + Vector2(0, -44), 15 * e["ttl"] / 0.4, Color(0.4, 1, 0.3, e["ttl"] / 0.4))
            if rock_frames.size() > 0:
                var rp: Texture2D = rock_frames[min(rock_frames.size() - 1, int((0.4 - e["ttl"]) / 0.08))]
                draw_texture_rect(rp, Rect2(e["p"] - Vector2(32, 14), Vector2(64, 48)), false)
    draw_rect(Rect2(0, 0, W, 116), Color(0.04, 0.1, 0.13, 0.75))
    label("LV %d" % level, Vector2(20, 45), 27, Color(1, 0.92, 0.64))
    label("HP %d/%d" % [hp, max_hp], Vector2(174, 45), 23, Color(1, 0.68, 0.68))
    label("KILLS %d" % kills, Vector2(365, 45), 21)
    draw_rect(Rect2(22, 72, 494, 21), Color(0.05, 0.1, 0.12))
    draw_rect(Rect2(25, 75, 488.0 * float(xp) / float(xp_target), 15), Color(0.2, 0.93, 0.38))
    label("XP %d/%d" % [xp, xp_target], Vector2(221, 109), 16)
    label("%ds" % int(time_alive), Vector2(22, 157), 21)
    if menu:
        draw_rect(Rect2(0, 0, W, H), Color(0.01, 0.04, 0.08, 0.82))
        label("LEVEL UP!", Vector2(145, 287), 42, Color(1, 0.87, 0.36))
        label("Choose one upgrade", Vector2(145, 332), 22)
        for i in range(3):
            draw_rect(Rect2(56, 354 + i * 100, 428, 78), Color(0.10, 0.25, 0.32), true)
            draw_rect(Rect2(56, 354 + i * 100, 428, 78), Color(0.94, 0.75, 0.35), false, 3.0)
            label(choices[i], Vector2(93, 404 + i * 100), 27)
    if dead:
        draw_rect(Rect2(0, 0, W, H), Color(0.03, 0.04, 0.07, 0.8))
        label("GAME OVER", Vector2(138, 422), 42, Color(1, 0.43, 0.35))
        label("Zombies defeated: %d" % kills, Vector2(138, 475), 22)
        label("TAP TO RESTART", Vector2(140, 538), 26)
