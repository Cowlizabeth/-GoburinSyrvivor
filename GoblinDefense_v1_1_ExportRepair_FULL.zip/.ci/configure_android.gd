extends SceneTree

func _initialize() -> void:
    var sdk := OS.get_environment("GODOT_CI_ANDROID_SDK")
    var java := OS.get_environment("JAVA_HOME")
    if sdk.is_empty() or java.is_empty():
        push_error("Missing SDK or JAVA_HOME")
        quit(1)
        return
    var settings: EditorSettings = EditorInterface.get_editor_settings()
    settings.set_setting("export/android/android_sdk_path", sdk)
    settings.set_setting("export/android/java_sdk_path", java)
    print("SET Android SDK = ", settings.get_setting("export/android/android_sdk_path"))
    print("SET Java SDK = ", settings.get_setting("export/android/java_sdk_path"))
    quit(0)
