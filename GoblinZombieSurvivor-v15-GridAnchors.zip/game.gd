extends Node2D

const Visuals = preload("res://scripts/config/visual_catalog.gd")
const EnemyCatalog = preload("res://scripts/config/enemy_catalog.gd")
const Weapons = preload("res://scripts/config/weapon_catalog.gd")
const ProgressStore = preload("res://scripts/services/progress_store.gd")

const CharacterVisual = preload("res://scenes/characters/CharacterVisual.tscn")

const W := 540.0
const H := 1200.0
const FLOOR := 1018.0
var hero_visual: Node2D
var hero_frames: Array[Texture2D] = []
var zombie_frames: Array[Texture2D] = []
var mage_cast_frames: Array[Texture2D] = []
var zombie_sets: Dictionary = {}
var bolt_frames: Array[Texture2D] = []
var bomb_frames: Array[Texture2D] = []
var explosion_frames: Array[Texture2D] = []
var fire_frames: Array[Texture2D] = []
var water_frames: Array[Texture2D] = []
var rock_frames: Array[Texture2D] = []
var forest: Texture2D
var rng := RandomNumberGenerator.new()
var enemies: Array = []
var shots: Array = []
var effects: Array = []
var time_alive := 0.0
var spawn_timer := 0.0
var shot_timer := 0.0
var run_frame := 0.0
var level := 1
var xp := 0
var xp_target := 5
var kills := 0
var hp := 5
var max_hp := 5
var damage := 1.0
var fire_interval := 1.75
var triple := 0
var fan := 0
var bombs := 0
var volley: Array = []
var menu := false
var dead := false
var choices: Array = []
var scroll := 0.0
var font: Font
var drops: Array = []
var coins_run := 0
var coins_total := 0
var permanent_damage := 0
var permanent_hp := 0
var permanent_rate := 0
var magnet_time := 0.0
var boss_timer := 90.0
var boss_kills := 0
var camera_shake := 0.0
var damage_numbers: Array = []
var pickup_textures: Dictionary = {}
var pending_cast_target := Vector2.ZERO
var save_path := "user://goblin_progress.cfg"

func _ready() -> void:
    rng.randomize()
    load_progress()
    forest = Visuals.world_background()
    hero_frames = Visuals.animation_frames(Visuals.HERO, "hero", Visuals.HERO_FRAMES)
    zombie_frames = Visuals.animation_frames(Visuals.ZOMBIE, "zombie", Visuals.ZOMBIE_FRAMES)
    for i in range(8):
        mage_cast_frames.append(load("res://assets/characters/goblin/cast_%02d.png" % i))
    for kind in ["normal", "fast", "boss"]:
        var move_textures: Array[Texture2D] = []
        var idle_textures: Array[Texture2D] = []
        var count: int = 5 if kind == "boss" else 6
        for i in range(count):
            move_textures.append(load("res://assets/characters/zombies/%s/walk_%02d.png" % [kind, i]))
        for i in range(4):
            idle_textures.append(load("res://assets/characters/zombies/%s/idle_%02d.png" % [kind, i]))
        zombie_sets[kind] = {"walk": move_textures, "idle": idle_textures}
    bolt_frames = Visuals.animation_frames(Visuals.BOLT, "bolt", Visuals.PROJECTILE_FRAMES)
    bomb_frames = Visuals.animation_frames(Visuals.BOMB, "bomb", Visuals.PROJECTILE_FRAMES)
    explosion_frames = Visuals.animation_frames(Visuals.EXPLOSION, "explosion", Visuals.EXPLOSION_FRAMES)
    fire_frames = Visuals.animation_frames(Visuals.ENVIRONMENT, "fire", Visuals.FIRE_FRAMES)
    water_frames = Visuals.animation_frames(Visuals.ENVIRONMENT, "water", Visuals.WATER_FRAMES)
    rock_frames = Visuals.animation_frames(Visuals.ENVIRONMENT, "rock", Visuals.ROCK_FRAMES)
    for kind in ["xp", "coin", "heal", "magnet"]:
        pickup_textures[kind] = Visuals.pickup_texture(kind)
    font = ThemeDB.fallback_font
    hero_visual = CharacterVisual.instantiate()
    add_child(hero_visual)
    hero_visual.setup(hero_frames, 11.0, Vector2(235, 235), [], mage_cast_frames, 420.0)
    # Cast frame 4: staff orb center at pixel ~263, 137 in 512x512 artwork.
    var staff_points: Array[Vector2] = [
        Vector2(306, 190), Vector2(318, 77), Vector2(317, 90), Vector2(307, 166),
        Vector2(263, 128), Vector2(311, 192), Vector2(310, 185), Vector2(300, 178)
    ]
    hero_visual.set_cast_muzzle_points(staff_points, Vector2(512, 512), 420.0)
    hero_visual.cast_release.connect(_on_hero_cast_release)
    hero_visual.position = Vector2(120, FLOOR + 3)
    print("GOBLIN GAME READY: textures loaded")
    reset()

func reset() -> void:
    for z in enemies:
        if z.has("visual") and is_instance_valid(z["visual"]):
            z["visual"].queue_free()
    enemies.clear()
    drops.clear()
    damage_numbers.clear()
    coins_run = 0
    magnet_time = 0.0
    boss_timer = 90.0
    camera_shake = 0.0
    shots.clear()
    effects.clear()
    volley.clear()
    time_alive = 0.0
    spawn_timer = 1.4
    shot_timer = 0.8
    run_frame = 0.0
    level = 1
    xp = 0
    xp_target = 5
    kills = 0
    max_hp = 5 + permanent_hp
    hp = max_hp
    damage = 1.0 + 0.25 * permanent_damage
    fire_interval = maxf(0.45, 1.7 * pow(0.9, permanent_rate))
    triple = 0
    fan = 0
    bombs = 0
    menu = false
    dead = false
    scroll = 0.0
    queue_redraw()

func _process(delta: float) -> void:
    if menu or dead:
        if is_instance_valid(hero_visual): hero_visual.set_paused(true)
        for z in enemies:
            if z.has("visual") and is_instance_valid(z["visual"]): z["visual"].set_paused(true)
        queue_redraw()
        return
    if is_instance_valid(hero_visual): hero_visual.set_paused(false)
    var dt: float = minf(delta, 0.05)
    time_alive += dt
    boss_timer -= dt
    if boss_timer <= 0.0:
        spawn_zombie("boss")
        boss_timer = 90.0
    magnet_time = maxf(0.0, magnet_time - dt)
    camera_shake = maxf(0.0, camera_shake - dt)
    for number in damage_numbers:
        number["ttl"] -= dt
        var new_point: Vector2 = number["p"]
        new_point.y -= 20.0 * dt
        number["p"] = new_point
    damage_numbers = damage_numbers.filter(func(n): return n["ttl"] > 0.0)
    run_frame += dt * 11.0
    scroll += dt * (26.0 + time_alive * 0.18)
    spawn_timer -= dt
    if spawn_timer <= 0.0:
        spawn_zombie()
        var base_rate: float = maxf(0.32, 2.1 - time_alive * 0.012 - float(level - 1) * 0.11)
        spawn_timer = base_rate * rng.randf_range(0.75, 1.35)
    shot_timer -= dt
    if shot_timer <= 0.0:
        auto_fire()
        shot_timer = fire_interval
    var pending_volley: Array = []
    for v in volley:
        v["delay"] -= dt
        if v["delay"] <= 0.0:
            fire_at(v["target"], v["spread"])
        else:
            pending_volley.append(v)
    volley = pending_volley
    update_projectiles(dt)
    update_zombies(dt)
    for z in enemies:
        if z.has("visual") and is_instance_valid(z["visual"]):
            z["visual"].position = z["p"] + Vector2(0, 15)
            z["visual"].set_paused(false)
    update_drops(dt)
    for e in effects:
        e["ttl"] -= dt
    effects = effects.filter(func(e): return e["ttl"] > 0.0)
    queue_redraw()

func spawn_zombie(forced: String = "") -> void:
    var kind := forced
    if kind == "":
        var roll := rng.randf()
        if time_alive > 60.0 and roll < 0.14:
            kind = "tank"
        elif time_alive > 25.0 and roll < 0.36:
            kind = "fast"
        else:
            kind = "normal"
    var hp_value: float = 1.4 + float(level - 1) * 0.45 + time_alive * 0.016
    var speed: float = 43.0 + minf(92.0, time_alive * 0.72) + level * 2.0
    var archetype: Dictionary = EnemyCatalog.get_archetype(kind)
    hp_value *= float(archetype["health"])
    speed *= float(archetype["speed"])
    var size: float = float(archetype["size"])
    var reward: int = int(archetype["reward"])
    enemies.append({"p": Vector2(W + 84.0, FLOOR), "hp": hp_value, "max": hp_value, "speed": speed, "anim": rng.randf_range(0.0, 6.0), "hit": 0.0, "kind": kind, "size": size, "reward": reward})

    var visual: Node2D = CharacterVisual.instantiate()
    add_child(visual)
    var last_enemy: Dictionary = enemies.back()
    last_enemy["visual"] = visual
    var skin_name: String = "boss" if kind == "boss" else ("fast" if kind == "fast" else "normal")
    var anim_set: Dictionary = zombie_sets[skin_name]
    visual.setup(anim_set["walk"], 12.0 if skin_name == "fast" else 8.0, Vector2(156, 192) * float(last_enemy["size"]), anim_set["idle"])
    visual.position = last_enemy["p"] + Vector2(0, 15)

func get_hero_muzzle() -> Vector2:
    if is_instance_valid(hero_visual):
        return hero_visual.get_muzzle_position()
    return Vector2(123.0, FLOOR - 127.0)

func auto_fire() -> void:
    if enemies.is_empty():
        return
    var best: Dictionary = enemies[0]
    var dist: float = INF
    for e in enemies:
        var d: float = get_hero_muzzle().distance_squared_to(e["p"])
        if d < dist:
            dist = d
            best = e
    pending_cast_target = best["p"] + Vector2(0.0, -98.0)
    if is_instance_valid(hero_visual):
        hero_visual.cast_spell(fire_interval)
    else:
        _on_hero_cast_release()

func _on_hero_cast_release() -> void:
    if menu or dead or enemies.is_empty():
        return
    # Reacquire an active target at the actual release frame.
    var best: Dictionary = enemies[0]
    var best_dist: float = INF
    var origin := get_hero_muzzle()
    for e in enemies:
        var d: float = origin.distance_squared_to(e["p"])
        if d < best_dist:
            best_dist = d
            best = e
    var aim: Vector2 = best["p"] + Vector2(0, -98)
    fire_at(aim, 0.0)
    for n in range(1, fan + 1):
        fire_at(aim, float(n) * 0.17)
        fire_at(aim, float(n) * -0.17)
    for i in range(triple):
        volley.append({"delay": 0.16 * float(i + 1), "target": aim, "spread": 0.0})
    for n in range(bombs):
        shots.append({"p": origin, "v": Vector2(195.0 + 25.0 * n, -370.0 - n * 35.0), "life": 3.0, "bomb": true, "dmg": damage * 2.5})

func fire_at(target: Vector2, spread: float) -> void:
    var origin := get_hero_muzzle()
    var dir: Vector2 = (target - origin).normalized().rotated(spread)
    shots.append({"p": origin, "v": dir * float(Weapons.MAGIC_BOLT["speed"]), "life": float(Weapons.MAGIC_BOLT["lifetime"]), "bomb": false, "dmg": damage})

func update_projectiles(dt: float) -> void:
    for s in shots:
        s["life"] -= dt
        s["p"] += s["v"] * dt
        if s["bomb"]:
            var vel: Vector2 = s["v"]
            vel.y += float(Weapons.BOMB["gravity"]) * dt
            s["v"] = vel
            if s["p"].y >= FLOOR - 8.0:
                explosion(Vector2(clampf(s["p"].x, 84.0, W - 84.0), FLOOR - 8.0), s["dmg"])
                s["life"] = -1.0
        else:
            for z in enemies:
                if s["p"].distance_to(z["p"] + Vector2(0, -118)) < 52.0:
                    z["hp"] -= s["dmg"]
                    show_damage(s["p"], s["dmg"])
                    z["hit"] = 0.12
                    effects.append({"p": s["p"], "ttl": 0.2, "kind": "hit"})
                    s["life"] = -1.0
                    break
    shots = shots.filter(func(s): return s["life"] > 0.0 and s["p"].x < W + 90.0 and s["p"].y < H + 80.0)

func explosion(point: Vector2, power: float) -> void:
    point.x = clampf(point.x, 84.0, W - 84.0)
    effects.append({"p": point, "ttl": 0.42, "kind": "boom"})
    camera_shake = 0.15
    for z in enemies:
        if (z["p"] + Vector2(0, -88)).distance_to(point + Vector2(0, -35)) < 140.0:
            z["hp"] -= power
            show_damage(z["p"] + Vector2(0, -100), power)
            z["hit"] = 0.18

func update_zombies(dt: float) -> void:
    var living: Array = []
    for z in enemies:
        var position: Vector2 = z["p"]
        position.x -= z["speed"] * dt
        z["p"] = position
        if position.x < -80.0:
            continue
        z["anim"] += dt * 8.0
        z["hit"] = maxf(0.0, z["hit"] - dt)
        if z["hp"] <= 0.0:
            kills += 1
            var reward: int = z["reward"]
            for i in range(reward):
                drops.append({"p": z["p"] + Vector2(rng.randf_range(-28.0, 28.0), -80.0 + rng.randf_range(-18.0, 18.0)), "kind": "xp", "value": 1})
            if rng.randf() < 0.33 or z["kind"] == "boss":
                drops.append({"p": z["p"] + Vector2(0, -115), "kind": "coin", "value": 4 if z["kind"] == "boss" else 1})
            if rng.randf() < 0.065:
                drops.append({"p": z["p"] + Vector2(0, -140), "kind": "heal", "value": 1})
            if rng.randf() < 0.025:
                drops.append({"p": z["p"] + Vector2(0, -140), "kind": "magnet", "value": 1})
            if z["kind"] == "boss":
                boss_kills += 1
                for i in range(9):
                    drops.append({"p": z["p"] + Vector2(rng.randf_range(-80.0, 80.0), -80), "kind": "coin", "value": 2})
            effects.append({"p": z["p"], "ttl": 0.4, "kind": "kill"})
        elif z["p"].x < 158.0:
            hp -= 1
            effects.append({"p": Vector2(120.0, FLOOR - 118.0), "ttl": 0.4, "kind": "hit"})
            if hp <= 0: dead = true
        else:
            living.append(z)
            continue
        if z.has("visual") and is_instance_valid(z["visual"]):
            z["visual"].queue_free()
    enemies = living

func gain_xp(amount: int) -> void:
    xp += amount
    if xp >= xp_target and not menu:
        xp -= xp_target
        level += 1
        damage += 0.25
        xp_target = 5 + level * 3
        menu = true
        choices = ["TRIPLE SHOT", "FAN SHOT", "BOMB"]

func _input(event: InputEvent) -> void:
    if not (event is InputEventScreenTouch or event is InputEventMouseButton): return
    if not event.pressed: return
    if dead:
        var touch: Vector2 = event.position
        if touch.y < get_viewport_rect().size.y * 0.65:
            reset()
        else:
            buy_permanent_upgrade()
        return
    if menu:
        var pos: Vector2 = event.position
        var scale_x: float = get_viewport_rect().size.x / W
        var scale_y: float = get_viewport_rect().size.y / H
        pos = Vector2(pos.x / scale_x, pos.y / scale_y)
        for i in range(3):
            if Rect2(42, 354 + i * 106, 456, 90).has_point(pos):
                if i == 0: triple += 1
                elif i == 1: fan += 1
                else: bombs += 1
                menu = false
                return

func show_damage(at: Vector2, points: float) -> void:
    damage_numbers.append({"p": at, "ttl": 0.5, "value": int(ceil(points))})

func update_drops(dt: float) -> void:
    var hero_target := Vector2(120.0, FLOOR - 100.0)
    var remaining: Array = []
    for d in drops:
        var pos: Vector2 = d["p"]
        pos.x -= (40.0 + time_alive * 0.15) * dt
        var range_pickup: float = 170.0 if magnet_time > 0 else 80.0
        if pos.distance_to(hero_target) < range_pickup:
            pos = pos.move_toward(hero_target, 450.0 * dt)
        d["p"] = pos
        if pos.distance_to(hero_target) < 34.0 or pos.x < 95.0:
            match d["kind"]:
                "xp": gain_xp(int(d["value"]))
                "coin":
                    coins_run += int(d["value"])
                    coins_total += int(d["value"])
                    save_progress()
                "heal": hp = mini(max_hp, hp + 1)
                "magnet": magnet_time = 9.0
        elif pos.x > -20:
            remaining.append(d)
    drops = remaining

func load_progress() -> void:
    var progress: Dictionary = ProgressStore.read_progress()
    coins_total = int(progress["coins"])
    permanent_damage = int(progress["damage"])
    permanent_hp = int(progress["hp"])
    permanent_rate = int(progress["rate"])

func save_progress() -> void:
    ProgressStore.write_progress({
        "coins": coins_total,
        "damage": permanent_damage,
        "hp": permanent_hp,
        "rate": permanent_rate,
    })

func buy_permanent_upgrade() -> void:
    var cost := 10 + 8 * (permanent_damage + permanent_hp + permanent_rate)
    if coins_total >= cost:
        coins_total -= cost
        if permanent_damage <= permanent_hp and permanent_damage <= permanent_rate:
            permanent_damage += 1
        elif permanent_hp <= permanent_rate:
            permanent_hp += 1
        else:
            permanent_rate += 1
        save_progress()

func tex(tex_in: Texture2D, at: Vector2, dims: Vector2, flip: bool = false) -> void:
    if tex_in == null: return
    draw_texture_rect(tex_in, Rect2(at + Vector2(-dims.x * 0.5, -dims.y), dims), false)

func label(text_value: String, pos: Vector2, size: int = 24, color: Color = Color.WHITE) -> void:
    draw_string(font, pos + Vector2(2, 2), text_value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(0.05, 0.08, 0.10, 0.85))
    draw_string(font, pos, text_value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func _draw() -> void:
    draw_rect(Rect2(0, 0, W, H), Color(0.15, 0.38, 0.55))
    # Extend the forest background vertically; lower strip remains the playable ground.
    draw_texture_rect(forest, Rect2(-fposmod(scroll * 0.24, 270.0), 110, 1100, FLOOR - 120.0), false)
    if water_frames.size() > 0:
        var wf: Texture2D = water_frames[int(time_alive * 8.0) % water_frames.size()]
        draw_texture_rect(wf, Rect2(396, 650, 84, 32), false)
    # Ground texture continues to bottom of portrait view, no gray letterbox.
    draw_rect(Rect2(0, FLOOR + 10, W, H - FLOOR), Color(0.11, 0.23, 0.16))
    for band in range(6):
        draw_rect(Rect2(0, FLOOR + 20 + band * 48, W, 18), Color(0.12, 0.22, 0.15, 0.12))
    draw_rect(Rect2(0, FLOOR, W, 10), Color(0.51, 0.75, 0.18))
    if fire_frames.size() > 0:
        draw_texture_rect(fire_frames[int(time_alive * 12.0) % fire_frames.size()], Rect2(458, FLOOR - 164, 34, 46), false)
    # horizon shimmer
    for i in range(7):
        var x: float = fposmod(float(i * 130) - scroll * 1.5, 780.0) - 90.0
        draw_rect(Rect2(x, FLOOR + 15, 34, 4), Color(0.35, 0.54, 0.17))
    if hero_frames.size() > 0:
        draw_circle(Vector2(120, FLOOR + 4), 22, Color(0.0, 0.0, 0.0, 0.18))
        draw_circle(Vector2(120, FLOOR + 5), 14, Color(0.0, 0.0, 0.0, 0.28))
        # Rendered by Hero CharacterVisual / AnimatedSprite2D.
    for z in enemies:
        draw_circle(z["p"] + Vector2(0, 6), 21, Color(0.0, 0.0, 0.0, 0.16))
        draw_circle(z["p"] + Vector2(0, 7), 13, Color(0.0, 0.0, 0.0, 0.24))
        var z_size: float = z["size"]
        # Rendered by each enemy CharacterVisual / AnimatedSprite2D.
        if z["kind"] == "boss" or z["kind"] == "tank":
            var bw: float = 90.0 * z_size
            draw_rect(Rect2(z["p"].x - bw * 0.5, z["p"].y - 205.0 * z_size, bw, 7), Color(0.16,0.10,0.09))
            draw_rect(Rect2(z["p"].x - bw * 0.5, z["p"].y - 205.0 * z_size, bw * maxf(0.0, z["hp"] / z["max"]), 7), Color(0.95,0.23,0.22))
        if z["hit"] > 0: draw_circle(z["p"] + Vector2(0, -85), 12, Color(1, 0.2, 0.2, 0.75))
    for d in drops:
        var dp: Vector2 = d["p"]
        var sprite: Texture2D = pickup_textures[d["kind"]]
        draw_texture_rect(sprite, Rect2(dp - Vector2(15, 15), Vector2(30, 30)), false)
    for s in shots:
        if s["bomb"]:
            draw_set_transform(s["p"], time_alive * 6.0)
            tex(bomb_frames[int(time_alive * 13) % 3], Vector2.ZERO, Vector2(44, 44))
            draw_set_transform(Vector2.ZERO, 0.0)
        else:
            var bolt: Texture2D = bolt_frames[int(time_alive * 18.0) % bolt_frames.size()]
            draw_set_transform(s["p"], s["v"].angle(), Vector2.ONE)
            draw_texture_rect(bolt, Rect2(-26, -16, 52, 32), false)
            draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    for e in effects:
        if e["kind"] == "boom":
            var phase: int = clampi(int((0.42 - e["ttl"]) / 0.42 * 6.0), 0, 5)
            draw_texture_rect(explosion_frames[phase], Rect2(e["p"] - Vector2(80, 80), Vector2(160, 160)), false)
        elif e["kind"] == "kill":
            draw_circle(e["p"] + Vector2(0, -44), 15 * e["ttl"] / 0.4, Color(0.4, 1, 0.3, e["ttl"] / 0.4))
            if rock_frames.size() > 0:
                var rp: Texture2D = rock_frames[min(rock_frames.size() - 1, int((0.4 - e["ttl"]) / 0.08))]
                draw_texture_rect(rp, Rect2(e["p"] - Vector2(32, 14), Vector2(64, 48)), false)
    for n in damage_numbers:
        label(str(n["value"]), n["p"], 19, Color(1.0,0.83,0.31))
    draw_rect(Rect2(0, 0, W, 116), Color(0.04, 0.1, 0.13, 0.75))
    label("LV %d" % level, Vector2(20, 45), 27, Color(1, 0.92, 0.64))
    label("HP %d/%d" % [hp, max_hp], Vector2(174, 45), 23, Color(1, 0.68, 0.68))
    label("KILLS %d" % kills, Vector2(365, 45), 21)
    draw_rect(Rect2(22, 72, 494, 21), Color(0.05, 0.1, 0.12))
    draw_rect(Rect2(25, 75, 488.0 * float(xp) / float(xp_target), 15), Color(0.2, 0.93, 0.38))
    label("XP %d/%d" % [xp, xp_target], Vector2(221, 109), 16)
    label("%ds" % int(time_alive), Vector2(22, 157), 21)
    label("COINS %d (+%d)" % [coins_total, coins_run], Vector2(300, 157), 18, Color(1.0,0.88,0.32))
    if menu:
        draw_rect(Rect2(0, 0, W, H), Color(0.01, 0.04, 0.08, 0.82))
        label("LEVEL UP!", Vector2(145, 287), 42, Color(1, 0.87, 0.36))
        label("Choose one upgrade", Vector2(145, 332), 22)
        for i in range(3):
            draw_rect(Rect2(42, 354 + i * 106, 456, 90), Color(0.10, 0.25, 0.32), true)
            draw_rect(Rect2(42, 354 + i * 106, 456, 90), Color(0.94, 0.75, 0.35), false, 3.0)
            label(choices[i], Vector2(86, 391 + i * 106), 26)
            var details := [str(Weapons.UPGRADE_OPTIONS[0]["description"]), str(Weapons.UPGRADE_OPTIONS[1]["description"]), str(Weapons.UPGRADE_OPTIONS[2]["description"])]
            label(details[i], Vector2(86, 419 + i * 106), 17, Color(0.79,0.91,0.92))
    if dead:
        draw_rect(Rect2(0, 0, W, H), Color(0.03, 0.04, 0.07, 0.8))
        label("GAME OVER", Vector2(138, 422), 42, Color(1, 0.43, 0.35))
        label("Zombies defeated: %d" % kills, Vector2(138, 475), 22)
        label("TAP TOP TO RESTART", Vector2(116, 535), 24)
        label("COINS: %d" % coins_total, Vector2(174, 585), 27, Color(1.0,0.84,0.3))
        var cost: int = 10 + 8 * (permanent_damage + permanent_hp + permanent_rate)
        label("TAP BOTTOM: PERMANENT UPGRADE", Vector2(48, 782), 20)
        label("Cost %d | DMG %d HP %d SPEED %d" % [cost, permanent_damage, permanent_hp, permanent_rate], Vector2(55, 820), 17)
