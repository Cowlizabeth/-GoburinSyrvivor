extends Node2D

signal cast_release

@onready var animation: AnimatedSprite2D = $AnimatedSprite2D
@onready var muzzle: Marker2D = $Muzzle
var previous_move := "move"
var cast_release_frame := 3
var cast_released := false
var cast_muzzle_pixels: Array[Vector2] = []
var reference_frame_size := Vector2(512.0, 512.0)
var reference_ground_pixel := 420.0

func setup(frames: Array, frame_rate: float, display_size: Vector2, idle_frames: Array = [], attack_frames: Array = [], ground_pixel: float = -1.0) -> void:
    var resource := SpriteFrames.new()
    resource.add_animation("move")
    resource.set_animation_speed("move", frame_rate)
    resource.set_animation_loop("move", true)
    for texture in frames:
        if texture != null:
            resource.add_frame("move", texture)
    if not idle_frames.is_empty():
        resource.add_animation("idle")
        resource.set_animation_speed("idle", 5.0)
        resource.set_animation_loop("idle", true)
        for texture in idle_frames:
            if texture != null:
                resource.add_frame("idle", texture)
    if not attack_frames.is_empty():
        resource.add_animation("cast")
        resource.set_animation_speed("cast", 8.0)
        resource.set_animation_loop("cast", false)
        for texture in attack_frames:
            if texture != null:
                resource.add_frame("cast", texture)
    animation.sprite_frames = resource
    if not frames.is_empty() and frames[0] != null:
        var size: Vector2 = frames[0].get_size()
        animation.scale = Vector2(display_size.x / size.x, display_size.y / size.y)
        # Root is the ground anchor. Sprite2D is centered, so subtract the
        # actual foot baseline, never the bottom of the transparent canvas.
        if ground_pixel >= 0.0:
            animation.offset = Vector2(0.0, size.y * 0.5 - ground_pixel)
        else:
            animation.offset = Vector2(0.0, -size.y * 0.5)
    if not animation.animation_finished.is_connected(_on_animation_finished):
        animation.animation_finished.connect(_on_animation_finished)
    if not animation.frame_changed.is_connected(_on_frame_changed):
        animation.frame_changed.connect(_on_frame_changed)
    if resource.get_frame_count("move") > 0:
        animation.play("move")

func set_cast_muzzle_points(points: Array[Vector2], frame_size: Vector2, ground_pixel: float) -> void:
    cast_muzzle_pixels = points.duplicate()
    reference_frame_size = frame_size
    reference_ground_pixel = ground_pixel
    if not cast_muzzle_pixels.is_empty():
        _apply_cast_muzzle(0)

func _apply_cast_muzzle(frame_index: int) -> void:
    if cast_muzzle_pixels.is_empty():
        return
    var index: int = clampi(frame_index, 0, cast_muzzle_pixels.size() - 1)
    set_muzzle_from_frame(cast_muzzle_pixels[index], reference_frame_size, reference_ground_pixel)

func set_muzzle_from_frame(pixel_position: Vector2, frame_size: Vector2, ground_pixel: float) -> void:
    # Pixel position is measured in the source PNG, not world coordinates.
    muzzle.position = Vector2(
        (pixel_position.x - frame_size.x * 0.5) * animation.scale.x,
        (pixel_position.y - ground_pixel) * animation.scale.y
    )

func get_muzzle_position() -> Vector2:
    return muzzle.global_position

func cast_spell(cast_duration: float = 1.0) -> void:
    if animation.sprite_frames == null or not animation.sprite_frames.has_animation("cast"):
        return
    var count: int = animation.sprite_frames.get_frame_count("cast")
    if count <= 0:
        return
    # A shorter fire interval means a faster complete cast animation.
    var duration: float = maxf(0.24, cast_duration)
    animation.sprite_frames.set_animation_speed("cast", float(count) / duration)
    cast_released = false
    if animation.animation != "cast":
        animation.play("cast")
        animation.set_frame_and_progress(0, 0.0)
        _apply_cast_muzzle(0)

func _on_frame_changed() -> void:
    if animation.animation == "cast":
        _apply_cast_muzzle(animation.frame)
        if animation.frame == cast_release_frame and not cast_released:
            cast_released = true
            cast_release.emit()

func _on_animation_finished() -> void:
    if animation.animation == "cast":
        animation.play(previous_move)

func set_paused(value: bool) -> void:
    if value:
        animation.pause()
    elif not animation.is_playing() and animation.sprite_frames != null and animation.sprite_frames.has_animation(previous_move) and animation.sprite_frames.get_frame_count(previous_move) > 0:
        animation.play(previous_move)
