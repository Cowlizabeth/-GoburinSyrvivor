extends SceneTree

func _initialize() -> void:
    var sdk: String = OS.get_environment("ANDROID_HOME")
    var java: String = OS.get_environment("JAVA_HOME")
    if sdk.is_empty() or java.is_empty():
        push_error("Android SDK or Java JDK 17 path is missing")
        quit(1)
        return
    if not FileAccess.file_exists(sdk.path_join("platform-tools/adb")):
        push_error("Invalid Android SDK directory: adb missing")
        quit(1)
        return
    if not FileAccess.file_exists(java.path_join("bin/java")):
        push_error("Invalid Java 17 directory: java missing")
        quit(1)
        return
    var settings: EditorSettings = EditorInterface.get_editor_settings()
    settings.set_setting("export/android/android_sdk_path", sdk)
    settings.set_setting("export/android/java_sdk_path", java)
    print("CI Android SDK:", settings.get_setting("export/android/android_sdk_path"))
    print("CI JDK:", settings.get_setting("export/android/java_sdk_path"))
    quit(0)
