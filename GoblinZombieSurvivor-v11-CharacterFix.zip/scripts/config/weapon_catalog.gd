extends RefCounted
## Animation, balance, and presentation defaults for weapons and upgrades.
## Combat execution remains in the main controller for this compatibility release.
const MAGIC_BOLT := {"speed": 470.0, "lifetime": 1.7, "frames": 3, "effect": "magic_bolt"}
const BOMB := {"gravity": 650.0, "lifetime": 3.0, "radius": 140.0, "effect": "explosion"}
const UPGRADE_OPTIONS := [
    {"id": "triple", "name": "TRIPLE SHOT", "description": "Extra delayed magic shot"},
    {"id": "fan", "name": "FAN SHOT", "description": "Two angled magic shots"},
    {"id": "bomb", "name": "BOMB", "description": "Arc bomb + area damage"},
]
