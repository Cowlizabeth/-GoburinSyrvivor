extends SceneTree

func _initialize() -> void:
    call_deferred("run_test")

func run_test() -> void:
    var scene: PackedScene = load("res://main.tscn")
    if scene == null:
        printerr("SMOKE FAILURE: main.tscn cannot load")
        quit(1)
        return
    var game: Node = scene.instantiate()
    if game == null or not game.has_method("spawn_zombie"):
        printerr("SMOKE FAILURE: game.gd did not compile or attach")
        quit(1)
        return
    root.add_child(game)
    await process_frame
    if game.get("hero_frames") == null or game.get("forest") == null:
        printerr("SMOKE FAILURE: game graphics not initialized")
        quit(1)
        return
    game.call("spawn_zombie")
    await process_frame
    if not game.is_inside_tree():
        printerr("SMOKE FAILURE: game not running")
        quit(1)
        return
    print("SMOKE PASS: main scene, script, images, and first frames started")
    quit(0)
