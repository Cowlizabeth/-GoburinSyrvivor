# Goblin Zombie Survivor — Android / Godot 4.4.1

Portrait prototype: goblin running in place, zombies moving from the right, auto targeting, XP and selectable upgrades (TRIPLE SHOT, FAN SHOT, BOMB), increasing difficulty, death/restart. All sprites are **actual PNG textures** cut from the illustrated sheet, used in `game.gd` directly. They are **not exported from StykAnimate**; that program may be used later to refine the animations. Frames are provisional and require manual clean-up for production consistency.

## Mobile GitHub instructions

1. Create a NEW empty GitHub repository to avoid conflict with the old workflow.
2. Extract this ZIP with Android file manager and upload **the contents** to the root of repository. GitHub website cannot unzip automatically. Hidden `.github/workflows/android-apk.yml` must be uploaded in its folder.
3. Actions → Build Goblin Survivor APK → newest run → Artifacts → GoblinSurvivor-Android → download ZIP containing APK.

The workflow has not been executed on GitHub in this delivery. First Android build may expose Godot script or SDK issues; do not assume release-readiness.


## v4 Animation Polish
Normalized opaque-frame bounds on 190x224 alpha canvases, bottom-aligned character frames, 540x1200 portrait scene, corrected bolt directions and collision origin. Godot runs the PNG frames directly. StykAnimate is a movement reference, not embedded or executed by this build.


## v5 — animation clean-up
- Corrupted frame crops replaced with coherent 224×256 transparent cels. All frames use the same feet baseline.
- The current animation is a **limited, loopable bob-cycle** based on intact artwork, not a StykAnimate export or fully re-drawn limb animation.
- Bullet targeting now aims at the zombie torso and the projectile launches from the goblin hand.
- Bomb explosions are centered at the world-space impact point and use six bounded 192×192 PNG frames.
- The existing GitHub Actions workflow can build this archive if it automatically discovers the newest ZIP in the repo.
