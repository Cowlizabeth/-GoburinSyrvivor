8 RUN frames and 8 CAST frames. All 384x384 RGBA; same source scaling (0.78) and same feet baseline. These are individual PNG assets; not yet integrated in Godot.
