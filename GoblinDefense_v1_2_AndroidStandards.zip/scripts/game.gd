extends Node2D

const W := 480.0
const H := 854.0
const FIELD_TOP := 104.0
const FIELD_BOTTOM := 716.0
const PATH_W := 49.0
const MAX_WAVES := 15
const TOWER_NAMES := ["ARCHER", "SHAMAN", "BOMBER", "FROST"]
const TOWER_COST := [55, 90, 125, 105]
const TOWER_DAMAGE := [12.0, 22.0, 36.0, 7.0]
const TOWER_RANGE := [124.0, 133.0, 113.0, 122.0]
const TOWER_RATE := [0.57, 1.16, 1.65, 0.96]
const TOWER_COLOR := [Color("e9be71"), Color("75dcfa"), Color("f08a58"), Color("a4e6f9")]
const PATH := [Vector2(490,176), Vector2(98,176), Vector2(98,338), Vector2(376,338), Vector2(376,507), Vector2(102,507), Vector2(102,649), Vector2(26,649)]
const SPOTS := [Vector2(58,256),Vector2(211,250),Vector2(322,249),Vector2(200,402),Vector2(433,410),Vector2(279,575),Vector2(56,575),Vector2(205,650)]

var gold := 180
var life := 20
var wave := 0
var selection := 0
var towers: Array[Dictionary] = []
var enemies: Array[Dictionary] = []
var shots: Array[Dictionary] = []
var sparks: Array[Dictionary] = []
var spawn_left := 0
var spawn_timer := 0.0
var wave_active := false
var wave_timer := 0.0
var finished := false
var victory := false
var selected_spot := -1
var status := "CHOOSE A TOWER, THEN TAP A PAD"
var status_timer := 0.0
var time_total := 0.0
var font: Font

func _ready() -> void:
    font = ThemeDB.fallback_font
    queue_redraw()

func note(message: String) -> void:
    status = message
    status_timer = 3.0

func _process(delta: float) -> void:
    var dt: float = minf(delta,0.05)
    time_total += dt
    if status_timer > 0.0:
        status_timer -= dt
    if not finished:
        if wave_active:
            spawn_timer -= dt
            if spawn_left > 0 and spawn_timer <= 0.0:
                spawn_enemy()
                spawn_left -= 1
                spawn_timer = maxf(0.28,0.95-float(wave)*0.028)
            move_enemies(dt)
            attack_from_towers(dt)
            move_shots(dt)
            if spawn_left == 0 and enemies.is_empty():
                wave_active = false
                if life > 0:
                    gold += 30 + wave * 5
                    note("WAVE CLEARED! BONUS GOLD")
                    if wave >= MAX_WAVES:
                        finished = true
                        victory = true
        else:
            wave_timer += dt
    for i in range(sparks.size()-1,-1,-1):
        var fx: Dictionary = sparks[i]
        fx["ttl"] = float(fx["ttl"]) - dt
        if float(fx["ttl"]) <= 0:
            sparks.remove_at(i)
        else:
            sparks[i] = fx
    queue_redraw()

func start_wave() -> void:
    if wave_active or finished:
        return
    wave += 1
    spawn_left = 7 + wave * 3
    if wave % 5 == 0:
        spawn_left += 1
    spawn_timer = 0.15
    wave_active = true
    note("HUMANS INCOMING! WAVE " + str(wave))

func spawn_enemy() -> void:
    var count := enemies.size()
    var enemy_type := 0
    if wave >= 3 and (count + spawn_left) % 5 == 0:
        enemy_type = 1
    if wave >= 5 and (count + spawn_left) % 7 == 0:
        enemy_type = 2
    if wave % 5 == 0 and spawn_left == 1:
        enemy_type = 3
    var hp: float = (42.0 + wave * 14.0) * [1.0,0.72,2.2,8.0][enemy_type]
    enemies.append({"pos": PATH[0],"segment": 0,"hp":hp,"maxhp":hp,"speed": [47.0,78.0,35.0,24.0][enemy_type] * (1.0 + wave*0.018),"type":enemy_type,"reward": [12,15,25,110][enemy_type],"slow":0.0})

func move_enemies(dt: float) -> void:
    for i in range(enemies.size()-1,-1,-1):
        var e: Dictionary = enemies[i]
        var seg: int = e["segment"]
        var position: Vector2 = e["pos"]
        var speed: float = e["speed"]
        if float(e["slow"]) > 0.0:
            speed *= 0.55
            e["slow"] = maxf(0.0,float(e["slow"])-dt)
        var distance_remaining := speed * dt
        while distance_remaining > 0.0 and seg < PATH.size()-1:
            var to: Vector2 = PATH[seg+1]-position
            var length := to.length()
            if length <= distance_remaining:
                position = PATH[seg+1]
                distance_remaining -= length
                seg += 1
            else:
                position += to.normalized()*distance_remaining
                distance_remaining = 0.0
        if seg >= PATH.size()-1:
            life -= 3 if int(e["type"]) == 3 else 1
            enemies.remove_at(i)
            sparks.append({"pos":PATH[-1],"ttl":0.7,"color":Color("ff5b65")})
            if life <= 0:
                life = 0
                finished = true
                victory = false
            continue
        e["pos"] = position
        e["segment"] = seg
        enemies[i] = e

func attack_from_towers(dt: float) -> void:
    for i in range(towers.size()):
        var t: Dictionary = towers[i]
        t["cooldown"] = maxf(0.0,float(t["cooldown"])-dt)
        if float(t["cooldown"]) > 0.0:
            towers[i] = t
            continue
        var best := -1
        var best_score := -INF
        var origin: Vector2 = SPOTS[int(t["spot"])]
        var kind: int = t["type"]
        var level: int = t["level"]
        for j in range(enemies.size()):
            var e: Dictionary = enemies[j]
            if origin.distance_to(e["pos"]) <= TOWER_RANGE[kind] * (1.0+float(level-1)*0.065):
                var progress: float = float(e["segment"]) * 1000.0 - origin.distance_to(e["pos"])
                if progress > best_score:
                    best_score = progress
                    best = j
        if best != -1:
            shots.append({"pos":origin + Vector2(0,-13),"target":enemies[best]["pos"],"speed": [390.0,295.0,240.0,310.0][kind],"type":kind,"damage":TOWER_DAMAGE[kind]*(1.0+float(level-1)*0.68),"radius": [0.0,0.0,53.0,0.0][kind]})
            t["cooldown"] = TOWER_RATE[kind] / (1.0+float(level-1)*0.14)
        towers[i] = t

func move_shots(dt: float) -> void:
    for i in range(shots.size()-1,-1,-1):
        var s: Dictionary = shots[i]
        var target: Vector2 = s["target"]
        var nearest := -1
        var mindist := 65.0
        for j in range(enemies.size()):
            var dist: float = s["pos"].distance_to(enemies[j]["pos"])
            if dist < mindist:
                nearest = j
                mindist = dist
        if nearest != -1:
            target = enemies[nearest]["pos"]
        var step: Vector2 = target - s["pos"]
        if step.length() <= float(s["speed"])*dt+12.0:
            shots.remove_at(i)
            var hit_pos: Vector2 = target
            if int(s["type"]) == 2:
                for j in range(enemies.size()-1,-1,-1):
                    if enemies[j]["pos"].distance_to(hit_pos) < float(s["radius"]):
                        damage_enemy(j,float(s["damage"])*0.8,false)
            elif nearest != -1:
                damage_enemy(nearest,float(s["damage"]),int(s["type"])==3)
            sparks.append({"pos":hit_pos,"ttl":0.32,"color":TOWER_COLOR[int(s["type"])]})
        else:
            s["pos"] = s["pos"] + step.normalized()*float(s["speed"])*dt
            s["target"] = target
            shots[i] = s

func damage_enemy(index: int, damage: float, freeze: bool) -> void:
    if index < 0 or index >= enemies.size():
        return
    var e: Dictionary = enemies[index]
    e["hp"] = float(e["hp"]) - damage
    if freeze:
        e["slow"] = 1.5
    if float(e["hp"]) <= 0.0:
        gold += int(e["reward"])
        enemies.remove_at(index)
    else:
        enemies[index] = e

func _input(event: InputEvent) -> void:
    if not (event is InputEventScreenTouch or event is InputEventMouseButton):
        return
    if event is InputEventScreenTouch and not event.pressed:
        return
    if event is InputEventMouseButton and not event.pressed:
        return
    var p: Vector2 = event.position
    if finished:
        if p.y > 700.0:
            restart()
        return
    if p.y > 766 and p.y < 832:
        if p.x < 386:
            selection = clampi(int(p.x/94.0),0,3)
            selected_spot = -1
        else:
            start_wave()
        return
    if p.y > 720 and p.y < 762:
        if selected_spot >= 0:
            upgrade_selected()
        else:
            start_wave()
        return
    for i in range(SPOTS.size()):
        if p.distance_to(SPOTS[i]) < 36.0:
            select_or_build(i)
            return
    selected_spot = -1

func select_or_build(spot: int) -> void:
    for t in towers:
        if int(t["spot"]) == spot:
            selected_spot = spot
            note("TAP UPGRADE TO IMPROVE THIS TOWER")
            return
    if gold < TOWER_COST[selection]:
        note("NOT ENOUGH GOLD")
        return
    gold -= TOWER_COST[selection]
    towers.append({"spot":spot,"type":selection,"level":1,"cooldown":0.2})
    selected_spot = spot
    note(TOWER_NAMES[selection]+" BUILT")

func upgrade_selected() -> void:
    for i in range(towers.size()):
        var t: Dictionary = towers[i]
        if int(t["spot"]) == selected_spot:
            var level: int = t["level"]
            if level >= 4:
                note("MAX LEVEL")
                return
            var cost := 45 * level + int(TOWER_COST[int(t["type"])]*0.7)
            if gold < cost:
                note("UPGRADE COSTS " + str(cost))
                return
            gold -= cost
            t["level"] = level+1
            towers[i] = t
            note("TOWER LEVEL " + str(level+1))
            return

func restart() -> void:
    gold=180
    life=20
    wave=0
    selection=0
    towers.clear()
    enemies.clear()
    shots.clear()
    sparks.clear()
    spawn_left=0
    spawn_timer=0.0
    wave_active=false
    finished=false
    victory=false
    selected_spot=-1
    note("NEW GAME")

func text_at(content:String, pos:Vector2, size:int=20, color:Color=Color.WHITE) -> void:
    draw_string(font,pos,content,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func rect(r:Rect2,color:Color) -> void:
    draw_rect(r,color)

func _draw() -> void:
    rect(Rect2(0,0,W,H),Color("1a302b"))
    draw_field()
    draw_path()
    draw_spots_and_towers()
    draw_enemies()
    draw_shots()
    draw_ui()
    if finished:
        rect(Rect2(0,0,W,H),Color(0.04,0.08,0.09,0.8))
        text_at("VICTORY!" if victory else "DEFEAT",Vector2(136,344),42,Color("b3ed91") if victory else Color("ff8989"))
        text_at("TAP BELOW TO RESTART",Vector2(101,752),20)

func draw_field() -> void:
    rect(Rect2(0,FIELD_TOP,W,FIELD_BOTTOM-FIELD_TOP),Color("456a40"))
    for y in range(118,716,36):
        for x in range(0,480,40):
            var odd := int(x/40 + y/36)%4
            rect(Rect2(x+4,y+5,31,25), Color("4d7745") if odd==0 else Color("456c3f"))
    for v in range(14):
        var xx: float = fmod(float(v*71+17),480.0)
        var yy: float = FIELD_TOP + fmod(float(v*97+39),590.0)
        draw_circle(Vector2(xx,yy),5,Color("83a55c"))

func draw_path() -> void:
    for i in range(PATH.size()-1):
        draw_line(PATH[i],PATH[i+1],Color("5b5039"),PATH_W+8,true)
        draw_line(PATH[i],PATH[i+1],Color("b8a279"),PATH_W,true)
        draw_line(PATH[i],PATH[i+1],Color("d0ba8c"),1.5,true)
    draw_circle(Vector2(25,649),22,Color("303b4a"))
    draw_colored_polygon(PackedVector2Array([Vector2(25,626),Vector2(45,650),Vector2(25,671),Vector2(8,649)]),Color("7be7fa"))
    draw_circle(Vector2(25,649),8,Color("dbffff"))

func draw_spots_and_towers() -> void:
    for i in range(SPOTS.size()):
        var pos: Vector2 = SPOTS[i]
        draw_circle(pos+Vector2(0,5),27,Color("263d30"))
        draw_circle(pos,23,Color("789d62"))
        draw_circle(pos,19,Color("344e36"))
        if selected_spot==i:
            draw_arc(pos,29,0,TAU,40,Color("ffdf72"),3.0,true)
        var occupied := false
        for t in towers:
            if int(t["spot"])==i:
                occupied=true
                draw_tower(pos,int(t["type"]),int(t["level"]))
                break
        if not occupied:
            text_at("+",pos+Vector2(-8,10),29,Color("e7f2ae"))

func draw_tower(p:Vector2,kind:int,level:int) -> void:
    rect(Rect2(p.x-16,p.y-8,32,27),Color("4f3e36"))
    rect(Rect2(p.x-12,p.y-21,24,18),Color("78665a"))
    draw_colored_polygon(PackedVector2Array([p+Vector2(-20,-17),p+Vector2(0,-34),p+Vector2(20,-17)]),TOWER_COLOR[kind])
    draw_circle(p+Vector2(0,-19),6,Color("e4f49d") if kind==0 else TOWER_COLOR[kind].lightened(0.35))
    text_at(str(level),p+Vector2(12,19),13,Color("fff5a6"))

func draw_enemies() -> void:
    for e in enemies:
        var p:Vector2=e["pos"]
        var kind:int=e["type"]
        var radius:float=[11.0,9.0,15.0,22.0][kind]
        draw_circle(p+Vector2(0,5),radius,Color("5b5643"))
        draw_circle(p,radius, [Color("dbb69b"),Color("9dc8cf"),Color("a4b3bd"),Color("d9bb7a")][kind])
        draw_circle(p+Vector2(3,-4),radius*0.45,Color("5c4e47"))
        draw_line(p+Vector2(-4,1),p+Vector2(4,1),Color("442e29"),2.0)
        rect(Rect2(p.x-radius,p.y-radius-10,radius*2,4),Color("402f38"))
        rect(Rect2(p.x-radius,p.y-radius-10,radius*2*maxf(0.0,float(e["hp"])/float(e["maxhp"])),4),Color("84e46f"))

func draw_shots() -> void:
    for s in shots:
        var p:Vector2=s["pos"]
        draw_circle(p,8,TOWER_COLOR[int(s["type"])] * Color(1,1,1,0.35))
        draw_circle(p,4,TOWER_COLOR[int(s["type"])] )
    for fx in sparks:
        draw_circle(fx["pos"],float(fx["ttl"])*29.0,fx["color"] * Color(1,1,1,0.24))

func draw_ui() -> void:
    rect(Rect2(0,0,W,104),Color("172e34"))
    text_at("GOBLIN DEFENSE",Vector2(17,33),27,Color("e8e1ac"))
    text_at("GOLD " + str(gold),Vector2(16,71),21,Color("f5ce72"))
    text_at("CRYSTAL " + str(life),Vector2(170,71),20,Color("b4e9ed"))
    text_at("WAVE " + str(wave)+"/"+str(MAX_WAVES),Vector2(327,71),18)
    rect(Rect2(0,716,W,138),Color("182e34"))
    if selected_spot >= 0:
        var t_level := -1
        var t_kind := selection
        for t in towers:
            if int(t["spot"]) == selected_spot:
                t_level = int(t["level"])
                t_kind = int(t["type"])
                break
        if t_level>=0:
            text_at("UPGRADE: " + (str(45*t_level+int(TOWER_COST[t_kind]*0.7)) if t_level<4 else "MAX"),Vector2(16,746),18,Color("f6d58a"))
    else:
        text_at("TAP A PAD TO BUILD",Vector2(16,746),18,Color("c5deb5"))
    rect(Rect2(333,725,139,33),Color("46745a"))
    text_at("UPGRADE" if selected_spot >= 0 else "NEXT WAVE",Vector2(344,748),13)
    for k in range(4):
        var bx:float=8.0+float(k)*94.0
        rect(Rect2(bx,772,90,60),Color("3e634f") if selection==k else Color("2a4547"))
        draw_circle(Vector2(bx+22,792),11,TOWER_COLOR[k])
        text_at(TOWER_NAMES[k],Vector2(bx+7,813),12)
        text_at(str(TOWER_COST[k])+" G",Vector2(bx+56,792),13,Color("ffdb88"))
    rect(Rect2(389,772,83,60),Color("a27c3d") if not wave_active else Color("53676b"))
    text_at("NEXT",Vector2(397,796),17)
    text_at("WAVE",Vector2(395,818),17)
    if status_timer > 0.0:
        rect(Rect2(30,678,420,29),Color("1d343c"))
        text_at(status,Vector2(36,698),14,Color("fff3cb"))
