# Goblin Zombie Survivor v8

Godot 4.4.1 pixel-art mobile portrait prototype. Android build via repository GitHub Actions workflow.

## New in v8
- Normal, fast, tank and boss zombies; boss appears every 90 seconds.
- Actual pixel-art XP crystals and coins, health pickups and magnet powerups.
- XP pickup, three upgrade cards, floating damage numbers, boss health bar.
- Coins saved to `user://goblin_progress.cfg` with three rotating persistent upgrades.
- More enemies and stronger enemies over time; auto fire, fan shot, volley and bombs retained.
- Six-frame run and walk animations, pixel FX from v6 and lower stage position from v7.

## Controls
- Game auto-runs and auto-shoots; tap one of the three level-up cards when it appears.
- After death tap the top part of the screen to restart, or the lower area to purchase a permanent upgrade if you have enough coins.
- Permanent upgrade purchase cycles through damage, maximum HP and faster shots.

## Important
The ZIP project has not been tested on a real Android device here. GitHub Actions compiles the APK; inspect the smoke-test stage and game logs before distribution. StykAnimate itself was not run; existing PNG frames are used by Godot.


## v10: Fixed sprite cutoffs
Regenerated all character frames with a stable, complete upper-body silhouette, retaining animated leg poses. Unified texture sizes, transparency margins and sprite foot anchors; see tools/validate_frames.py.

## v11 Character Scene Refactor
- Actors render via scenes/characters/CharacterVisual.tscn with AnimatedSprite2D.
- Each sprite frame is a **whole PNG**, not upper-body/lower-body composites.
- Shared floor-anchor setup in scripts/characters/character_visual.gd.
- Current combat, loot, and progression logic retained in game.gd for compatibility.
- This is a transition to scene-based architecture; the rest of the code is not yet fully modular.
- APK and on-device rendering are not validated in this environment.


## v12 New Mage Hero
Replaced the active player hero with the newly drawn goblin mage run animation (9 frames, 256x256 each). The wide-spaced individual mage frames are also included under `assets/characters/goblin/` as `idle_*`, `run_*`, and `cast_*` for future state-based animation switching.


## v13 Attack + Zombie Visuals
- Hero uses 9-frame run loop from v12 and a new 8-frame casting animation triggered when autofiring.
- Zombies now use separate normal/fast/boss walking PNG sets; 4 idle frames each are included and loaded.
- Hero and zombies remain scene-based AnimatedSprite2D.
- Images are placed on 256x256 transparent canvases.
- This build has not been verified on an Android phone.


## v13.1 Godot 4.4 type compatibility fix
Fixed CharacterVisual.setup optional array arguments to accept regular GDScript Array instances; additionally checks that move frames exist before playing the animation. No changes to GitHub Actions required.


## v13.2 Polish Fix
- Normalized goblin cast frames so attack animation stays the same visual scale as the run animation.
- Synchronized projectile release with the blue-fire cast pose by delaying projectile spawn to the cast keyframe.
- Lowered zombie render anchors closer to the ground.
- Cleaned isolated left-edge sprite fragments from zombie frames and removed tiny stray pixels.


## v13.3 Mage Polish
- Re-normalized goblin mage cast frames based on the non-magic body silhouette, so the hero body keeps the same perceived size during run and cast.
- Added a dedicated hero muzzle position and moved projectile spawning closer to the casting hand instead of above the head.
- Slightly lowered aim target from cast shots to keep bolts centered on enemies from the new muzzle height.


## v13.4 Hero/Boss Fix
- Re-normalized every goblin mage state (run, idle, cast, and active hero frames) to one common body scale and one common ground line.
- Cleaned detached boss zombie fragments that were showing above the sprite.
- Slightly reduced boss visual size to avoid the cropped/oversized look while keeping boss stats unchanged.


## v14 New Mage Animations
- Replaced the goblin mage run and cast animations with a newly regenerated 8-frame run cycle and 8-frame cast cycle.
- Added the new frames both as run_00..07 and hero_0..8 for compatibility with the current game code.
- Cast animation uses the matching new mage frames from the same design set.


## v14.2 Mage Staff + Flash Fix
- Rebuilt the goblin mage run and cast animations on 512x512 canvases so staff and magic flare fit inside the frame.
- Re-sliced the cast animation from the original cast sheet with custom per-frame slices to restore the missing staff / blue flash pieces.
- Increased hero display size in game.gd to keep the in-game mage close to the previous apparent scale after moving to larger canvases.


## v14.3 Staff muzzle and frame-synced casting
- CharacterVisual has a real Marker2D Muzzle on the staff orb in cast frame 4.
- Spawn time is driven by AnimatedSprite2D.frame_changed, not a magic delay.
- Cast animation duration follows the current fire_interval, including permanent rate upgrades.
- Ground anchor for 512px hero frames is pixel y=420, not the PNG bottom.
- Extra triple projectiles follow after the release event.


## v15 Frame Grid Anchors
See docs/FRAME_COORDINATE_GRID.md for per-frame staff anchor coordinates. The magic shot is emitted at frame 4 from the frame-specific Marker2D position.


## v18 - Contour mage
Six contour-cut frames installed for both running and casting. Common 768x768 canvas and foot baseline at 620, same visual scale. Animated shot from blue staff crystal, release on fourth cast frame. Android APK runtime not yet checked.
